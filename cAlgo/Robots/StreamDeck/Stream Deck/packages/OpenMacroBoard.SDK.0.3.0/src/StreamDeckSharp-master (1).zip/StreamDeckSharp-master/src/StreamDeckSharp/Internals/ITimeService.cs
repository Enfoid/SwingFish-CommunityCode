﻿namespace StreamDeckSharp.Internals
{
    internal interface ITimeService
    {
        long GetRelativeTimestamp();
    }
}
